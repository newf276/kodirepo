# -*- coding: utf-8 -*-
import xbmc, xbmcgui
import json
from threading import Thread

pause_services_prop = 'finder.pause_services'
firstrun_update_prop = 'finder.firstrun_update'
current_skin_prop = 'finder.current_skin'
trakt_service_string = 'TraktMonitor Service Update %s - %s'
trakt_success_line_dict = {'success': 'Trakt Update Performed', 'no account': '(Unauthorized) Trakt Update Performed'}
update_string = 'Next Update in %s minutes...'

def logger(heading, function):
	xbmc.log('###%s###: %s' % (heading, function), 1)

class SetAddonConstants:
	def run(self):
		logger('Finder', 'SetAddonConstants Service Starting')
		import xbmcaddon, xbmcvfs
		window = xbmcgui.Window(10000)
		_info = xbmcaddon.Addon('plugin.video.finder').getAddonInfo
		addon_items = [('finder.addon_version', _info('version')),
					('finder.addon_path', _info('path')),
					('finder.addon_profile', xbmcvfs.translatePath(_info('profile'))),
					('finder.addon_icon', xbmcvfs.translatePath(_info('icon'))),
					('finder.addon_fanart', xbmcvfs.translatePath(_info('fanart')))]
		for item in addon_items: window.setProperty(*item)
		return logger('Finder', 'SetAddonConstants Service Finished')

class DatabaseMaintenance:
	def run(self):
		logger('Finder', 'DatabaseMaintenance Service Starting')
		from caches.base_cache import make_databases
		make_databases()
		return logger('Finder', 'DatabaseMaintenance Service Finished')

class SyncSettings:
	def run(self):
		logger('Finder', 'SyncSettings Service Starting')
		from caches.settings_cache import sync_settings
		sync_settings()
		logger('Finder', 'SyncSettings Service Finished')

class CustomFonts:
	def run(self):
		logger('Finder', 'CustomFonts Service Starting')
		from windows.base_window import FontUtils
		monitor, player, window = xbmc.Monitor(), xbmc.Player(), xbmcgui.Window(10000)
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		window.clearProperty(current_skin_prop)
		font_utils = FontUtils()
		while not monitor.abortRequested():
			font_utils.execute_custom_fonts()
			wait_for_abort(20)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return logger('Finder', 'CustomFonts Service Finished')

class TraktMonitor:
	def run(self):
		logger('Finder', 'TraktMonitor Service Starting')
		from apis.trakt_api import trakt_sync_activities
		from caches.settings_cache import get_setting
		from modules.kodi_utils import run_plugin
		from modules.settings import trakt_sync_interval
		monitor, player, window = xbmc.Monitor(), xbmc.Player(), xbmcgui.Window(10000)
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while is_playing() or window.getProperty(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				sync_interval, wait_time = trakt_sync_interval()
				next_update_string = update_string % sync_interval
				status = trakt_sync_activities()
				if status == 'failed': logger('Finder', trakt_service_string % ('Failed. Error from Trakt', next_update_string))
				else:
					if status in ('success', 'no account'): logger('Finder', trakt_service_string % ('Success. %s' % trakt_success_line_dict[status], next_update_string))
					else: logger('Finder', trakt_service_string % ('Success. No Changes Needed', next_update_string))# 'not needed'
					if status == 'success' and get_setting('finder.trakt.refresh_widgets', 'false') == 'true': run_plugin({'mode': 'kodi_refresh'})
			except Exception as e: logger('Finder', trakt_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return logger('Finder', 'TraktMonitor Service Finished')

class UpdateCheck:
	def run(self):
		window = xbmcgui.Window(10000)
		if window.getProperty(firstrun_update_prop) == 'true': return
		logger('Finder', 'UpdateCheck Service Starting')
		from time import time
		from modules.updater import update_check
		from modules.settings import update_action, update_delay
		end_pause = time() + update_delay()
		monitor, player = xbmc.Monitor(), xbmc.Player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while time() < end_pause: wait_for_abort(1)
			while window.getProperty(pause_services_prop) == 'true' or is_playing(): wait_for_abort(1)
			update_check(update_action())
			break
		window.setProperty(firstrun_update_prop, 'true')
		try: del monitor
		except: pass
		try: del player
		except: pass
		return logger('Finder', 'UpdateCheck Service Finished')

class WidgetRefresher:
	def run(self):
		logger('Finder', 'WidgetRefresher Service Starting')
		from time import time
		from caches.settings_cache import get_setting
		from indexers.random_lists import refresh_widgets
		from modules.kodi_utils import home
		monitor, player = xbmc.Monitor(), xbmc.Player()
		wait_for_abort, self.is_playing = monitor.waitForAbort, player.isPlayingVideo
		self.window, self.get_setting, self.home = xbmcgui.Window(10000), get_setting, home
		wait_for_abort(10)
		self.set_next_refresh(time())
		while not monitor.abortRequested():
			try:
				wait_for_abort(10)
				offset = int(self.get_setting('finder.widget_refresh_timer', '60'))
				if offset != self.offset:
					self.set_next_refresh(time())
					continue
				if self.condition_check(): continue
				if self.next_refresh < time():
					logger('Finder', 'WidgetRefresher Service - Widgets Refreshed')
					refresh_widgets(show_notification='true')
					self.set_next_refresh(time())
			except: pass
		try: del monitor
		except: pass
		try: del player
		except: pass
		return logger('Finder', 'WidgetRefresher Service Finished')

	def condition_check(self):
		if not self.home(): return True
		if self.next_refresh == None or self.is_playing() or self.window.getProperty(pause_services_prop) == 'true': return True
		if self.window.getProperty('finder.window_loaded') == 'true': return True 
		try:
			window_stack = json.loads(self.window.getProperty('finder.window_stack'))
			if window_stack or window_stack == []: return True
		except: pass
		return False

	def set_next_refresh(self, _time):
		self.offset = int(self.get_setting('finder.widget_refresh_timer', '60'))
		if self.offset: self.next_refresh = _time + (self.offset*60)
		else: self.next_refresh = None

class AutoStart:
	def run(self):
		logger('Finder', 'AutoStart Service Starting')
		from modules.settings import auto_start_finder
		if auto_start_finder():
			from modules.kodi_utils import run_addon
			run_addon()
		return logger('Finder', 'AutoStart Service Finished')

class AddonXMLCheck:
	def run(self):
		logger('Finder', 'AddonXMLCheck Service Starting')
		import xbmcvfs
		from xml.dom.minidom import parse as mdParse
		from modules.kodi_utils import list_dirs, translate_path
		self.addon_xml = xbmcvfs.translatePath('special://home/addons/plugin.video.finder/addon.xml')
		self.root = mdParse(self.addon_xml)
		self.change_file = False
		self.check_property('reuse_language_invoker', 'reuselanguageinvoker')
		self.check_property('addon_icon_choice', 'icon')
		self.change_xml_file()
		return logger('Finder', 'AddonXMLCheck Service Finished')

	def check_property(self, setting, tag_name):
		from caches.settings_cache import get_setting
		current_addon_setting = get_setting('finder.%s' % setting, None)
		if current_addon_setting is None: return
		tag_instance = self.root.getElementsByTagName(tag_name)[0].firstChild
		current_property = tag_instance.data
		if current_property != current_addon_setting:
			tag_instance.data = current_addon_setting
			self.change_file = True

	def change_xml_file(self):
		if not self.change_file: return
		from modules.kodi_utils import update_local_addons, disable_enable_addon, notification
		notification('Refreshing Addon XML After Update. Restarting Addons')
		new_xml = str(self.root.toxml()).replace('<?xml version="1.0" ?>', '')
		with open(self.addon_xml, 'w') as f: f.write(new_xml)
		logger('Finder', 'AddonXMLCheck Service - Change Detected. Restarting Addons')
		xbmc.executebuiltin('ActivateWindow(Home)', True)
		update_local_addons()
		disable_enable_addon()


class FinderMonitor(xbmc.Monitor):
	def __init__ (self):
		xbmc.Monitor.__init__(self)
		self.startServices()

	def startServices(self):
		SetAddonConstants().run()
		DatabaseMaintenance().run()
		SyncSettings().run()
		AddonXMLCheck().run()
		Thread(target=CustomFonts().run).start()
		Thread(target=TraktMonitor().run).start()
		Thread(target=UpdateCheck().run).start()
		Thread(target=WidgetRefresher().run).start()
		AutoStart().run()

	def onNotification(self, sender, method, data):
		if method in ('GUI.OnScreensaverActivated', 'System.OnSleep'):
			xbmcgui.Window(10000).setProperty(pause_services_prop, 'true')
			logger('OnNotificationActions', 'PAUSING Finder Services Due to Device Sleep')
		elif method in ('GUI.OnScreensaverDeactivated', 'System.OnWake'):
			xbmcgui.Window(10000).clearProperty(pause_services_prop)
			logger('OnNotificationActions', 'UNPAUSING Finder Services Due to Device Awake')

logger('Finder', 'Main Monitor Service Starting')
FinderMonitor().waitForAbort()
logger('Finder', 'Main Monitor Service Finished')
