import sys
from xbmc import executebuiltin, sleep

mode = sys.argv[1]
if   mode == 'refresh_widgets':
	executebuiltin('UpdateLibrary(video,special://skin/foo)')
elif mode == 'flix_watched_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('flix_watched_params'))
	sleep(1000)
	executebuiltin('UpdateLibrary(video,special://skin/foo)')
elif mode == 'flix_unwatched_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('flix_unwatched_params'))
	sleep(1000)
	executebuiltin('UpdateLibrary(video,special://skin/foo)')
elif mode == 'flix_clearprog_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('flix_clearprog_params'))
	sleep(1000)
	executebuiltin('UpdateLibrary(video,special://skin/foo)')
elif mode == 'flix_browse_params':
	executebuiltin('ActivateWindow(Videos,%s)' % sys.listitem.getProperty('flix_browse_params'))
elif mode == 'flix_browse_seas_params':
	executebuiltin('ActivateWindow(Videos,%s)' % sys.listitem.getProperty('flix_browse_seas_params'))
elif mode == 'flix_trakt_manager_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('flix_trakt_manager_params'))
elif mode == 'flix_fav_manager_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('flix_fav_manager_params'))
elif mode == 'flix_random_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('flix_random_params'))
elif mode == 'flix_options_menu_params':
	executebuiltin('RunPlugin(%s)' % sys.listitem.getProperty('flix_options_menu_params'))
elif mode == 'flix_extras_menu_params':
	params = sys.listitem.getProperty('flix_extras_menu_params')
	params += '&is_widget=false&is_home=true'
	executebuiltin('RunPlugin(%s)' % params)

